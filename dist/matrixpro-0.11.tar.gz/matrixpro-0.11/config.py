config_dict = {
    'background_image': 'bg.jpg',
    'background_places': (700, 0),
    'eachline_character': 85,
    'pairing_symbols': ['()', '[]', "''", '""'],
    'wraplines_number': 2
}
path_enable_list = ['background_image']